import 'dart:async';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:main/Pages/Pagina_Login.dart';
import 'NewTask.dart';
import 'CancelTask.dart';
import 'FinalTask.dart';



class Pagina_Dashboard extends StatefulWidget {
  const Pagina_Dashboard({Key? key}) : super(key: key);

  @override
  State<Pagina_Dashboard> createState() => _PaginaDasboardState();
}

var _Path = 'Todas'; //Declaração da variavél utilizada para definir o endpoint a ser utilizado

class Constants {
  static const IconData allIcon = Icons.all_inclusive;
  static const IconData dayIcon = Icons.calendar_today;
  static const IconData pendingIcon = Icons.pending;
  static const IconData futureIcon = Icons.timer;
  static const IconData logoutIcon = Icons.logout;

  //Declaração das constantes utilizadas no dropdown menu
  static const String FirstItem =
      'Todas'; //Declaração do primeiro item da lista
  static const String SecondItem = 'Dia'; //Declaração do segundo item da lista
  static const String ThirdItem =
      'Pendentes'; //Declaração do terceiro item da lista
  static const String FourthItem =
      'Futuras'; //Declaração do quarto item da lista
  static const String FifthItem = 'Logout'; //Declaração do quinto item da lista
  static const List<String> choices = <String>[
    //Declaração da lista do dropdown menu
    FirstItem,
    //Primeiro item
    SecondItem,
    //Segundo item
    ThirdItem,
    //Terceiro item
    FourthItem,
    //Quarto item
    FifthItem,
    //Quinto item
  ];
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();


  runApp(MaterialApp(home: Cancelar(listaTarefas: {}))); // Provide the required 'listaTarefas' parameter
}








class EditPage extends StatefulWidget {
  const EditPage({required this.listaTarefas});

  final Map<String, dynamic> listaTarefas;

  @override
  _EditPageState createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  String selectedOption = 'Reunião';
  String selectedUser = 'Manager';
  String selectedStatus = 'Sem Status';
  TextEditingController _assuntoTarefaController = TextEditingController();
  TextEditingController _descricaoTarefaController = TextEditingController();
  TextEditingController _inicioTarefaController = TextEditingController();
  TextEditingController _fimTarefaController = TextEditingController();

  Future<void> _editTask(Map<String, dynamic> taskData) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String? _token = sharedPreferences.getString('login_token');

    if (_token != null) {
      final Map<String, String> _headers = {
        'Content-Type': 'application/json',
        'Charset': 'utf-8',
        'Authorization': 'Bearer $_token',
      };

      final String endpoint = 'https://demo.spot4all.com/dashboard-tarefa/${taskData['tarefa_id']}';
      print('Endpoint: $endpoint'); // Print the endpoint URL for debugging

      final response = await http.put(
        Uri.parse(endpoint),
        headers: _headers,
        body: json.encode(taskData),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final status = responseData['status'];
        final message = responseData['message'];

        if (status) {
          print(message);
        } else {
          print('Failed to update the task: $message');
        }
      } else {
        print('Request error: ${response.statusCode}');
      }
    } else {
      print('Token not found.');
    }
  }

  Future<void> _selectDate(BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2025),
    );

    if (picked != null && picked != DateTime.now()) {
      setState(() {
        controller.text = picked.toString(); // Modify the format as needed
      });
    }
  }

  int retrieveContactId() {
    // Replace with your logic to retrieve the actual contact_id
    return 824;
  }

  int retrieveSubContactId() {
    // Replace with your logic to retrieve the actual sub_contact_id
    return 13;
  }

  void _saveTask() {
    // Get the values from the controllers
    String assuntoTarefa = _assuntoTarefaController.text;
    String descricaoTarefa = _descricaoTarefaController.text;
    String inicioTarefa = _inicioTarefaController.text;
    String fimTarefa = _fimTarefaController.text;

    // Retrieve the contact_id and sub_contact_id using the defined methods
    int contactId = retrieveContactId();
    int subContactId = retrieveSubContactId();

    // Create a map with the task data
    Map<String, dynamic> taskData = {
      'assunto': assuntoTarefa,
      'descricao': descricaoTarefa,
      'inicio': inicioTarefa,
      'fim': fimTarefa,
      'contact_id': contactId,
      'sub_contact_id': subContactId,
      'status': 0,
      'process_id': 217,
      'project_id': 0,
      'status_tarefa': 1,
      'campaign_step': 0,
    };

    // Check if the tarefa_id is present in the widget's listaTarefas
    if (widget.listaTarefas.containsKey('tarefa_id')) {
      // Existing task: Add the tarefa_id to the task data
      taskData['tarefa_id'] = widget.listaTarefas['tarefa_id'];

      // Call the edit task method with the task data
      _editTask(taskData);
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Editar Tarefa',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Tipo de Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedOption,
            onChanged: (value) {
              setState(() {
                selectedOption = value ?? selectedOption;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Reunião',
                child: Text('Reunião'),
              ),
              DropdownMenuItem<String>(
                value: 'Tarefa',
                child: Text('Tarefa'),
              ),
              DropdownMenuItem<String>(
                value: 'Telefonema',
                child: Text('Telefonema'),
              ),
              DropdownMenuItem<String>(
                value: 'Visita ao cliente',
                child: Text('Visita ao cliente'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Atribuir Utilizador',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedUser,
            onChanged: (value) {
              setState(() {
                selectedUser = value ?? selectedUser;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Manager',
                child: Text('Manager'),
              ),
              DropdownMenuItem<String>(
                value: 'Sergio Rafael',
                child: Text('Sergio Rafael'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Status',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
            value: selectedStatus,
            onChanged: (value) {
              setState(() {
                selectedStatus = value ?? selectedStatus;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Sem Status',
                child: Text('Sem Status'),
              ),
              DropdownMenuItem<String>(
                value: 'Em Andamento',
                child: Text('Em Andamento'),
              ),
              DropdownMenuItem<String>(
                value: 'Concluído',
                child: Text('Concluído'),
              ),
              DropdownMenuItem<String>(
                value: 'Cancelado',
                child: Text('Cancelado'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Assunto da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _assuntoTarefaController,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Descrição da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _descricaoTarefaController,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Início da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _inicioTarefaController,
            onTap: () => _selectDate(context, _inicioTarefaController),
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.calendar_today,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Fim da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _fimTarefaController,
            onTap: () => _selectDate(context, _fimTarefaController),
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.calendar_today,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _saveTask,
            child: const Text('Guardar Alterações'),
          ),
        ],
      ),
    );
  }
}



class NewProcessPage extends StatefulWidget {
  @override
  _NewProcessPageState createState() => _NewProcessPageState();
}

class _NewProcessPageState extends State<NewProcessPage> {
  String selectedSubcontacto = 'Aloha,Lda';
  String selectedModulo = 'CRM';
  String selectedWorkflow = '';
  String selectedStatus = 'Sem Status';
  String selectedProjecto = 'Sem projeto Associado';

  TextEditingController _assuntoTarefaController = TextEditingController();
  TextEditingController _descricaoTarefaController = TextEditingController();

  List<String> subcontactos = [
    'Aloha,Lda',
  ];

  List<String> modulos = [
    'CRM',
    'Intermediario de crédito',
    'Processual',
  ];

  Map<String, List<String>> moduleWorkflows = {
    'CRM': [
      'Angariaçoes',
      'Comercial',
      'DagolDemo',
      'DemoNutrição',
      'Funil de demostrações',
      'IC',
      'Reclamações',
      'ResidenciasOnLine'
    ],
    'Intermediario de crédito': [
      '1',
    ],
    'Processual': [
      'Fluxo operacional 1',
    ],
  };

  List<String> statuses = [
    'Sem Status',
    'Agendamento de Deslocação',
    'Aguarda Feedback',
    'Em tratamento',
    'Pendente',
    'Resolvido',
  ];

  List<String> projetos = [
    'Sem projeto Associado',
  ];

  DateTime? selectedDate;

  @override
  void initState() {
    super.initState();
    _fetchUserId();
  }

  Future<void> _fetchUserId() async {
    setState(() {
    });
  }

  Future<void> _saveTask() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String? _token = sharedPreferences.getString('login_token');

    // Create the process payload
    Map<String, dynamic> processData = {
      'Nome': _assuntoTarefaController.text,
      'Fonte': _descricaoTarefaController.text,
      'Descrição': _descricaoTarefaController.text,
      'Selecionar contacto': selectedSubcontacto,
      'Selecionar Subcontacto': selectedSubcontacto,
      'Selecionar Módulo': selectedModulo,
      'Selecionar Workflow': selectedWorkflow,
      'Selecionar Status': selectedStatus,
      'Selecionar Projeto': selectedProjecto,
      'Data Limite': selectedDate?.toString() ?? '',
    };

    print('Process Data: $processData'); // Print the process data

    // Send the request to create the process
    final response = await http.post(
      Uri.parse('https://demo.spot4all.com/newProcess'),
      body: jsonEncode(processData),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      },
    );

    // Print the response information
    print('Status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 302) {
      // Redirect detected
      final redirectLocation = response.headers['location'];
      print('Redirect Location: $redirectLocation'); // Add this line to print the redirect location
      if (redirectLocation != null) {
        // Send a new request to the redirected location
        final redirectResponse = await http.get(
          Uri.parse(redirectLocation),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer $_token',
          },
        );

        // Print the redirect response information
        print('Redirect status code: ${redirectResponse.statusCode}');
        print('Redirect response body: ${redirectResponse.body}');

        if (redirectResponse.statusCode == 200) {
          // Process created successfully after redirect
          print('Process created');
        } else {
          // Error creating process after redirect
          print(
              'Error creating process after redirect. Status code: ${redirectResponse.statusCode}');
          print('Error response body: ${redirectResponse.body}');
        }
      } else {
        // Error: Redirect location not provided
        print('Error: Redirect location not provided');
      }
    } else if (response.statusCode == 200) {
      // Process created successfully without redirect
      print('Process created');
    } else {
      // Error creating process
      print('Error creating process. Status code: ${response.statusCode}');
      print('Error response body: ${response.body}');
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> workflows = moduleWorkflows[selectedModulo] ?? [];
    if (!workflows.contains(selectedWorkflow)) {
      selectedWorkflow = workflows.isNotEmpty ? workflows[0] : '';
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Novo Processo',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          Text(
            'Nome',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          TextFormField(
            controller: _assuntoTarefaController,
            decoration: InputDecoration(
              hintText: '',
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            'Fonte',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          TextFormField(
            controller: _descricaoTarefaController,
            decoration: InputDecoration(
              hintText: '',
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            'Descrição',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          TextFormField(
            controller: _descricaoTarefaController,
            decoration: InputDecoration(
              hintText: '',
            ),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar contacto',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            // Other properties...
            value: selectedSubcontacto,
            onChanged: (value) {
              setState(() {
                selectedSubcontacto = value ?? selectedSubcontacto;
              });
            },
            items: subcontactos.map((String subcontacto) {
              return DropdownMenuItem<String>(
                value: subcontacto,
                child: Text(subcontacto),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar Subcontacto',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            // Other properties...
            value: selectedSubcontacto,
            onChanged: (value) {
              setState(() {
                selectedSubcontacto = value ?? selectedSubcontacto;
              });
            },
            items: subcontactos.map((String subcontacto) {
              return DropdownMenuItem<String>(
                value: subcontacto,
                child: Text(subcontacto),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar Módulo',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          DropdownButtonFormField<String>(
            // Other properties...
            value: selectedModulo,
            onChanged: (value) {
              setState(() {
                selectedModulo = value ?? selectedModulo;
              });
            },
            items: modulos.map((String modulo) {
              return DropdownMenuItem<String>(
                value: modulo,
                child: Text(modulo),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar Workflow',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          DropdownButtonFormField<String>(
            value: selectedWorkflow,
            onChanged: (value) {
              setState(() {
                selectedWorkflow = value ?? selectedWorkflow;
              });
            },
            items: workflows.map((String workflow) {
              return DropdownMenuItem<String>(
                key: Key(workflow), // Add a unique key for each DropdownMenuItem
                value: workflow,
                child: Text(workflow),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar Status',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          DropdownButtonFormField<String>(
            // Other properties...
            value: selectedStatus,
            onChanged: (value) {
              setState(() {
                selectedStatus = value ?? selectedStatus;
              });
            },
            items: statuses.map((String status) {
              return DropdownMenuItem<String>(
                value: status,
                child: Text(status),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Selecionar Projeto',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          DropdownButtonFormField<String>(
            // Other properties...
            value: selectedProjecto,
            onChanged: (value) {
              setState(() {
                selectedProjecto = value ?? selectedProjecto;
              });
            },
            items: projetos.map((String projeto) {
              return DropdownMenuItem<String>(
                value: projeto,
                child: Text(projeto),
              );
            }).toList(),
          ),
          SizedBox(height: 16.0),
          Text(
            'Data Limite',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ElevatedButton(
            onPressed: _selectDate,
            child: Text(
              selectedDate != null
                  ? '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}'
                  : 'Selecionar Data',
            ),
          ),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _saveTask,
            child: Text('Criar'),
          ),
        ],
      ),
    );
  }
}



class MessagePage extends StatefulWidget {
  @override
  _MessagePageState createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> {
  final TextEditingController commentController = TextEditingController();
  bool? notifyUserByEmail = false;
  bool? notifySubcontactByEmail = false;
  bool? notifyCreatorByEmail = false;

  void postComment(BuildContext context) async {
    SharedPreferences _sharedPreferences =
    await SharedPreferences.getInstance();
    String? _token = _sharedPreferences.getString('login_token');

    String _url = 'https://demo.spot4all.com/notas-tarefas/1411'; // Replace with your desired URL

    Map<String, String> _headers = {
      'Content-Type': 'application/json',
      'Charset': 'utf-8',
      'Authorization': 'Bearer $_token',
    };

    Map<String, dynamic> requestBody = {
      'comment': commentController.text,
      'notifyUserByEmail': notifyUserByEmail,
      'notifySubcontactByEmail': notifySubcontactByEmail,
      'notifyCreatorByEmail': notifyCreatorByEmail,
    };

    final response = await http.post(Uri.parse(_url),
        headers: _headers, body: jsonEncode(requestBody));

    if (response.statusCode == 200) {
      // Comment posted successfully
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Comment posted successfully.'),
        ),
      );
    } else {
      // Failed to post comment
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to post comment. Error: ${response.statusCode}'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Observações da Tarefa',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Observações da tarefa:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              TextFormField(
                maxLines: 9,
                controller: commentController,
                decoration: InputDecoration(
                  hintText: 'Digite um comentário breve',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Notificações:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              CheckboxListTile(
                title: Text('Notificar utilizador por email'),
                value: notifyUserByEmail!,
                onChanged: (value) {
                  // Atualizar o estado da checkbox
                  setState(() {
                    notifyUserByEmail = value;
                  });
                },
              ),
              CheckboxListTile(
                title: Text('Notificar subcontacto por email'),
                value: notifySubcontactByEmail!,
                onChanged: (value) {
                  // Atualizar o estado da checkbox
                  setState(() {
                    notifySubcontactByEmail = value;
                  });
                },
              ),
              CheckboxListTile(
                title: Text('Notificar criador por email'),
                value: notifyCreatorByEmail!,
                onChanged: (value) {
                  // Atualizar o estado da checkbox
                  setState(() {
                    notifyCreatorByEmail = value;
                  });
                },
              ),
              ElevatedButton(
                onPressed: () {
                  postComment(context); // Call the function to post the comment
                },
                child: Text('Post Comment'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _PaginaDasboardState extends State<Pagina_Dashboard> {
  Map<String, dynamic> taskData = {
    'title': 'Task Title',
    'description': 'Task Description',
    'data_evento': '2023-06-16',
    'data_evento_end': '2023-06-17',
    // Add more fields as needed
  };
  //final _formkey = GlobalKey<FormState>();
  List<Widget> _Lista_Widgets = []; //Declaração da lista do cartões da tarefas
  List<Widget> _list_widgets = [];

  bool _isTarefasButtonPressed = false;
  bool _isProcessosButtonPressed = false;

  //Declaração da lista de cartões enquanto os mesmos estão a ser chamados na função de ir buscar todas as tarefas
  void _navigateToEditScreen(Map<String, dynamic> listaTarefas) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditPage(listaTarefas: listaTarefas)),
    );
  }

  void _sendMessage() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => MessagePage()),
    );
  }

  void _cancelTask(Map<String, dynamic> listaTarefas) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Cancelar(listaTarefas: listaTarefas)),
    );
  }

  void _finalizeTask(Map<String, dynamic> taskData) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Finalizar(listaTarefas: taskData),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    todasTarefas(); //Iniciar a função que vai buscar todas as tarefas
  }
  bool _isCreatingTask = true; // Initially set to true since the button is for creating a task
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'DashBoard',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
        leading: PopupMenuButton<String>(
          // Create the dropdown menu
          icon: const Icon(Icons.menu), // Place the icon
          onSelected: choiceAction, // Implement the function to handle each option
          itemBuilder: (BuildContext context) {
            // Activate the builder
            return Constants.choices.map((String choice) {
              return PopupMenuItem<String>(
                // Build the popup
                value: choice,
                child: Row(
                  children: [
                    Icon(getIconForChoice(choice)),
                    const SizedBox(width: 8),
                    Text(choice),
                  ], // Place the text of the item list
                ),
              );
            }).toList();
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 15, right: 15), // Add top padding
            child: Container(
              width: double.infinity, // Make the button full width
              child: ElevatedButton(
                onPressed: () {
                  if (_isCreatingTask) {
                    // Implement the logic for creating a new task
                    // This is the function that will be called when the button is pressed
                    // You can add your implementation here

                    // Navigate to a new page when the button is clicked
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => NewTaskPage()),
                    );
                  } else {
                    // Implement the logic for creating a new process
                    // This is the function that will be called when the button is pressed
                    // You can add your implementation here
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => NewProcessPage()),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green, // Set the background color to green
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12.0), // Add padding within the button
                  child: Text(
                    _isCreatingTask ? 'Criar nova Tarefa' : 'Criar novo Processo',
                    style: TextStyle(
                      color: Colors.white, // Set the text color to white
                      fontSize: 18, // Set the font size of the text
                    ),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 16), // Add a SizedBox with desired height for spacing
          Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _isTarefasButtonPressed = true;
                      _isProcessosButtonPressed = false;
                      _isCreatingTask = true; // Switch back to creating a task when the "Tarefas" button is clicked
                    });

                    // Handle the first button press (TAREFAS)
                    Future.wait([
                      getTarefas('todas-tarefas-pendentes'),
                      getTarefas('todas-tarefas-dia'),
                      getTarefas('todas-tarefas-futuras'),


                    ]).then((List<List<Widget>> results) {
                      List<Widget> allTasks = results.expand((list) => list).toList();
                      setState(() {
                        _Lista_Widgets = allTasks;
                      });
                    });
                  },
                  style: TextButton.styleFrom(
                    backgroundColor: _isTarefasButtonPressed ? Color(0xFF2c55ca) : Colors.white  ,
                  ),
                  child: Text(
                    'TAREFAS',
                    style: TextStyle(
                      color: _isTarefasButtonPressed ? Colors.white : Colors.black,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _isTarefasButtonPressed = false;
                      _isProcessosButtonPressed = true;
                      _isCreatingTask = false; // Switch to creating a process when the "Processos" button is clicked
                    });

                    /// Handle the second button press (PROCESSOS)
                    getProcessos('todos-processos-atrasados').then((List<Widget> processosAtrasados) {
                      getProcessos('todos-processos-dia').then((List<Widget> processosDia) {
                        getProcessos('todos-processos-futuros').then((List<Widget> processosFuturos) {
                          setState(() {
                            _Lista_Widgets = [...processosAtrasados, ...processosDia, ...processosFuturos];
                          });
                        });
                      });
                    });
                  },
                  style: TextButton.styleFrom(
                    backgroundColor: _isProcessosButtonPressed ? Color(0xFF2c55ca) : Colors.white,
                  ),
                  child: Text(
                    'PROCESSOS',
                    style: TextStyle(
                      color: _isProcessosButtonPressed ? Colors.white : Colors.black,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _Lista_Widgets.length,
              itemBuilder: (context, index) {
                return _Lista_Widgets[index];
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<List<Widget>> getProcessos(String path) async {
    List<Widget> processos = [];
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String? token = sharedPreferences.getString('login_token');
    int? id = sharedPreferences.getInt('id_user');

    var cardColor = 0xFFf2c4c4; // Default color for processos

    if (path == 'todos-processos-futuros') {
      cardColor = 0xFF9db5f6;
    } else if (path == 'todos-processos-dia') {
      cardColor = 0xFFf5e8b3;
    } else if (path == 'todos-processos-atrasados') {
      cardColor = 0xFFf2c4c4;
    }

    try {
      String url = 'https://demo.spot4all.com/$path/$id';
      print('URL: $url');

      Map<String, String> headers = {
        'Content-Type': 'application/json',
        'Charset': 'utf-8',
        'Authorization': 'Bearer $token',
      };

      final response = await http.get(Uri.parse(url), headers: headers);
      if (response.statusCode == 200) {
        List<dynamic> listaMapas = jsonDecode(response.body);

        for (int counter = 0; counter < listaMapas.length; counter++) {
          Map<String, dynamic> listaProcessos = listaMapas[counter];
          String? moduleName = listaProcessos['module'];

          // Fetch data for specific modules
          if (moduleName == 'crm' ||
              moduleName == 'ic2' ||
              moduleName == 'proc') {
            String status_name = listaProcessos['status_name'];
            String? dateLimitString = listaProcessos['date_limit'];
            DateTime? dateLimit = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .parse(dateLimitString ?? '');
            String? board = listaProcessos['board'];
            String? menu = listaProcessos['menu'];
            String? description = listaProcessos['description'];
            String? title = listaProcessos['title'];
            String? consultor = listaProcessos['consultor'];
            String? criador = listaProcessos['criador'];
            int? id = listaProcessos['id'];


            // Create the processoWidget with the appropriate color
            Widget processoWidget = Container(
              padding: const EdgeInsets.all(10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  height: 250,
                  color: Color(cardColor), // Set the color property using cardColor
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: '${listaProcessos['nome']}',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextSpan(
                              text: ' - $title ($id)',
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.grey[800],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              '${board ?? ''}',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(width: 10), // Add space here
                            Text(
                              '(${menu ?? ''})',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 10), // Add space here
                      Text(
                        '${description ?? ''}',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10), // Add space here
                      Text(
                        // ignore: unnecessary_null_comparison
                        '${dateLimit != null ? DateFormat('yyyy-MM-dd').format(dateLimit) : ''} - ${consultor ?? ''}',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10), // Add space here
                      Text(
                        'Status: $status_name',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10), // Add space here
                      Text(
                        'Criado por $criador',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );

            processos.add(processoWidget);
          }
        }// Closing bracket for for loop
      } else {
        print('Request failed with status: ${response.statusCode}');
      } // Closing bracket for else condition
    } catch (e) {
      print('Error: $e');
    } // Closing bracket for catch block

    return processos;
  } // Closing bracket for method

  IconData getIconForChoice(String choice) {
    switch (choice) {
      case Constants.FirstItem:
        return Constants.allIcon;
      case Constants.SecondItem:
        return Constants.dayIcon;
      case Constants.ThirdItem:
        return Constants.pendingIcon;
      case Constants.FourthItem:
        return Constants.futureIcon;
      case Constants.FifthItem:
        return Constants.logoutIcon;
      default:
        return Icons.error;
    }
  }

  //Função que realiza o request á base de dados, e cria os cartões das tarefas
  Future<List<Widget>> getTarefas(String path) async {
    List<Widget> _Lista_Widget_Tarefas = []; //Declaração da lista provisória dos cartões
    SharedPreferences _sharedPreferences = await SharedPreferences.getInstance(); //Ativar a livraria do shared preferences
    String? _token = _sharedPreferences.getString('login_token'); //Colocar o token numa variável
    int? _id = _sharedPreferences.getInt('id_user'); //Colocar o id do utilizador numa variável

    var _BC = 5; //Definir a variável da cor do cartão

    if (path == 'todas-tarefas-pendentes') {
      //Trocar a cordo cartão para a cor dos cartões pendentes
      _BC = 0xFFf2c4c4;
    } else if (path == 'todas-tarefas-dia') {
      //Trocar a cordo cartão para a cor dos cartões diários
      _BC = 0xFFf5e8b3;
    } else if (path == 'todas-tarefas-futuras') {
      //Trocar a cordo cartão para a cor dos cartões futuros
      _BC = 0xFF9db5f6;
    }

    try {
      String _url = 'https://demo.spot4all.com/$path/$_id';

      Map<String, String> _headers = {
        'Content-Type': 'application/json',
        'Charset': 'utf-8', // Add a comma here
        'Authorization': 'Bearer $_token',
      };

      try {
        final response = await http.get(Uri.parse(_url), headers: _headers);
        if (response.statusCode == 200) {
          List<dynamic> _Lista_Mapas = jsonDecode(response.body);

          for (int counter = 0; counter < _Lista_Mapas.length; counter++) {
            Map<String, dynamic> _Lista_Tarefas = _Lista_Mapas[counter];
            if (_Lista_Tarefas['status_tarefa'] == 1) {
              String _id_contactos = 'id:${_Lista_Tarefas['tarefa_id']} - ${_Lista_Tarefas['name'] ?? ''} - (${_Lista_Tarefas['nickname'] ?? ''})';
              String _title_status = _Lista_Tarefas['title'] + ' - ' + (_Lista_Tarefas['status_name']?.toString() ?? '');
              String _subject = _Lista_Tarefas['subject'] ?? '';
              String _description = _Lista_Tarefas['description'] ?? '';
              String _dataend_assigned = '${_Lista_Tarefas['data_evento_end']?.toString()?.substring(0, 10) ?? ''} - ${_Lista_Tarefas['consultor'] ?? ''}';
              String _creator = 'Criado por: ${_Lista_Tarefas['criador'] ?? ''}';


// Additional processo fields handling
              String _consultor = _Lista_Tarefas['consultor'] ?? '';
              String _createdBy = _Lista_Tarefas['criador'] ?? '';
              int _id = _Lista_Tarefas['id'] ?? 0;
              int _contactId = _Lista_Tarefas['contact_id'] ?? 0;
              String _moduleName = _Lista_Tarefas['module'] ?? '';

              // Display the processo information
              print('Processo ID: $_id');
              print('Consultor: $_consultor');
              print('Criado por: $_createdBy');
              print('Contact ID: $_contactId');
              print('Module: $_moduleName');


              Widget containerWidget = Padding(
                padding: const EdgeInsets.all(10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    height: 250,
                    color: Color(_BC),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _id_contactos,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              _title_status,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _subject,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                              ),
                            ),
                            Text(
                              _description,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _dataend_assigned,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                              ),
                            ),
                            Text(
                              _creator,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      // Handle API request for the message icon
                                      // Implement the desired behavior
                                      _sendMessage();
                                    },
                                    child: const Icon(
                                      Icons.message,
                                      // Add any additional properties for the message icon, such as size or color
                                    ),
                                  ),
                                  const SizedBox(width: 25),
                                  GestureDetector(
                                    onTap: () {
                                      // Handle API request for the edit icon
                                      // Implement the desired behavior
                                      _navigateToEditScreen(_Lista_Tarefas);
                                    },
                                    child: const Icon(
                                      Icons.edit,
                                      // Add any additional properties for the edit icon, such as size or color
                                    ),
                                  ),
                                  const SizedBox(width: 25),
                                  GestureDetector(
                                    onTap: () {
                                      // Handle API request for the cancel icon
                                      // Implement the desired behavior
                                      _cancelTask(_Lista_Tarefas);
                                    },
                                    child: const Icon(
                                      Icons.cancel,
                                      // Add any additional properties for the cancel icon, such as size or color
                                    ),
                                  ),
                                  const SizedBox(width: 25),
                                  GestureDetector(
                                    onTap: () {
                                      _finalizeTask(_Lista_Tarefas); // Call _finalizeTask when the widget is tapped
                                    },
                                    child: const Icon(
                                      Icons.done_outline_outlined,
                                      // Add any additional properties for the done icon, such as size or color
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );

              _Lista_Widget_Tarefas.add(
                  containerWidget); //Colocar os cartões na lista
            }
          }
          ;
        } else {
          print('Failed to fetch data: ${response.statusCode}');
        }
      } catch (e) {
        print('Failed to fetch data: $e');
      }
      return _Lista_Widget_Tarefas; //Returnar a lista dos cartões
    } catch (e) {
      print('Failed to get data: $e');
      return _Lista_Widget_Tarefas; //Returnar a lista dos cartões
    }
  }


  //Função que inicia o processo de criar os cartões
  Future<void> _initializeListaWidgets() async {
    List<Widget> listaWidgets =
    await getTarefas(_Path); //Iniciar a função para criar os cartões
    setState(() {
      _Lista_Widgets = listaWidgets; //Returnar a lista dos cartões
    });
  }

  //Função que inicia o processo de criar os cartões quando a opção é para ir buscar todas as tarefas
  //Função que inicia o processo de criar os cartões quando a opção é para ir buscar todas as tarefas
  Future<void> _initializeListaWidgets_todas() async {
    List<Widget> listaWidgets =
    await getTarefas(_Path); //Iniciar a função para criar os cartões
    setState(() {
      _list_widgets.addAll(listaWidgets); //Adicionar os cartões á lista
    });
  }

  //Função que realiza a pesquisa de todas as tarefass
  Future<void> todasTarefas() async {
    _list_widgets =
    []; //Declaração da lista onde os cartões estarão guardados enquanto a função vai buscar o resto dos cartões
    int counter = 0; //Declaração do contador
    while (counter < 3) {
      //Definição do loop
      if (counter == 0) {
        _Path =
        'todas-tarefas-pendentes'; //Declaração da primeira entrada na função
      } else if (counter == 1) {
        _Path = 'todas-tarefas-dia'; //Declaração da segunda entrada na função
      } else if (counter == 2) {
        _Path = 'todas-tarefas-futuras'; //Declaração da terceira entrada na função
      } else if (counter == 1) {

        break; //Acabar o loop
      }
      await _initializeListaWidgets_todas(); //Envoção da lista para realizar a criação dos cartões
      counter += 1; //Aumentar o contador
    }
    _Lista_Widgets = _list_widgets; //Colocar os cartões na lista dos cartões
  }

  //Função que realiza a escolha no dropdown menu
  void choiceAction(String choice) {
    if (choice == Constants.FirstItem) {
      //Primeiro item selecionado, realiza a pesquisa de todas as tarefas
      //todas
      todasTarefas();
    } else if (choice == Constants.SecondItem) {
      //Segundo item selecionado, realiza a pesquisa das tarefas do dia
      //dia
      _Path = 'todas-tarefas-dia';
      _initializeListaWidgets();
    } else if (choice == Constants.ThirdItem) {
      //Terceiro item selecionado, realiza a pesquisa das tarefas pendentes
      //pendentes
      _Path = 'todas-tarefas-pendentes';
      _initializeListaWidgets();
    } else if (choice == Constants.FourthItem) {
      //Quarto item selecionado, realiza a pesquisa das tarefas futuras
      //futuras
      _Path = 'todas-tarefas-futuras';
      _initializeListaWidgets();
    } else if (choice == Constants.FifthItem) {
      //Quinto item selecionado, realiza o logout
      //logout
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (context) => const Pagina_Login()));
    }
  }
}