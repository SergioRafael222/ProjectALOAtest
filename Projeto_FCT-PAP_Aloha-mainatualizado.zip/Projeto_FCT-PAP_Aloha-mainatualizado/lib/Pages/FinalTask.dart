import 'dart:async';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:main/Pages/Pagina_Login.dart';




class Finalizar extends StatefulWidget {
  const Finalizar({required this.listaTarefas});

  final Map<String, dynamic> listaTarefas;

  @override
  _FinalizarState createState() => _FinalizarState();
}

class _FinalizarState extends State<Finalizar> {
  bool isCheckedSubcontacto = false;
  bool isCheckedEmail = false;
  TextEditingController observationsController = TextEditingController();

  Future<void> _finalizeTask(Map<String, dynamic> taskData) async {

    // Print the value of tarefa_id
    print('Tarefa ID: ${taskData['tarefa_id']}');

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String? _token = sharedPreferences.getString('login_token');

    if (_token != null) {
      final Map<String, String> _headers = {
        'Content-Type': 'application/json',
        'Charset': 'utf-8',
        'Authorization': 'Bearer $_token',
      };

      // Retrieve the values of 'contact_id' and 'sub_contact_id' dynamically
      int contactId = taskData['contact_id'];
      int subContactId = taskData['sub_contact_id'];

      final data = {
        'tarefa_id': taskData['tarefa_id'],
        'notify': 0,
        'notify_entity': 0,
        'contact_id': contactId,
        'sub_contact_id': subContactId,
      };

      final response = await http.post(
        Uri.parse('https://demo.spot4all.com/concluir-tarefa'), // Replace with the appropriate endpoint for finalizing tasks
        headers: _headers,
        body: json.encode(data),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final status = responseData['status'];
        final message = responseData['message'];

        if (status) {
          print(message);
        } else {
          print('Failed to finalize the task: $message');
        }
      } else {
        print('Request error: ${response.statusCode}');
      }
    } else {
      print('Token not found.');
    }
  }

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> _Lista_Tarefas = widget.listaTarefas;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Finalizar Tarefa',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Icon(
                    Icons.check_circle_outline,
                    size: 150,
                    color: Colors.greenAccent,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Finalizar Tarefa:',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    Checkbox(
                      value: isCheckedSubcontacto,
                      onChanged: (value) {
                        setState(() {
                          isCheckedSubcontacto = value ?? false;
                        });
                      },
                    ),
                    const Text(
                      'Notificar subcontacto por email',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    Checkbox(
                      value: isCheckedEmail,
                      onChanged: (value) {
                        setState(() {
                          isCheckedEmail = value ?? false;
                        });
                      },
                    ),
                    const Text(
                      'Notificar por email',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: observationsController,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: 'Observações',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _finalizeTask(_Lista_Tarefas); // Call _finalizeTask instead of _cancelTask
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    minimumSize: const Size(140, 45),
                  ),
                  child: const Text(
                    'FINALIZAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 15),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Navigate back to the previous route (main page)
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    minimumSize: const Size(140, 45),
                  ),
                  child: const Text(
                    'VOLTAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}