import 'dart:async';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:main/Pages/Pagina_Login.dart';




class Cancelar extends StatefulWidget {
  const Cancelar({required this.listaTarefas});

  final Map<String, dynamic> listaTarefas;

  @override
  _CancelarState createState() => _CancelarState();
}

class _CancelarState extends State<Cancelar> {
  bool isCheckedSubcontacto = false;
  bool isCheckedEmail = false;
  TextEditingController observationsController = TextEditingController();

  Future<void> _cancelTask(Map<String, dynamic> taskData) async {

    // Print the value of tarefa_id
    print('Tarefa ID: ${taskData['tarefa_id']}');

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String? _token = sharedPreferences.getString('login_token');

    if (_token != null) {
      final Map<String, String> _headers = {
        'Content-Type': 'application/json',
        'Charset': 'utf-8',
        'Authorization': 'Bearer $_token',
      };

      // Retrieve the values of 'contact_id' and 'sub_contact_id' dynamically
      int contactId = taskData['contact_id'];
      int subContactId = taskData['sub_contact_id'];

      final data = {
        'tarefa_id': taskData['tarefa_id'],
        'notify': 0,
        'notify_entity': 0,
        'contact_id': contactId,
        'sub_contact_id': subContactId,
      };

      final response = await http.post(
        Uri.parse('https://demo.spot4all.com/cancelar-tarefa'), // Replace with the appropriate endpoint for canceling tasks
        headers: _headers,
        body: json.encode(data),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final status = responseData['status'];
        final message = responseData['message'];

        if (status) {
          print(message);
        } else {
          print('Failed to cancel the task: $message');
        }
      } else {
        print('Request error: ${response.statusCode}');
      }
    } else {
      print('Token not found.');
    }
  }

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> _Lista_Tarefas = widget.listaTarefas;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Cancelar Tarefa',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 150,
                    color: Colors.orangeAccent,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Cancelar Tarefa:',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    Checkbox(
                      value: isCheckedSubcontacto,
                      onChanged: (value) {
                        setState(() {
                          isCheckedSubcontacto = value ?? false;
                        });
                      },
                    ),
                    const Text(
                      'Notificar subcontacto por email',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    Checkbox(
                      value: isCheckedEmail,
                      onChanged: (value) {
                        setState(() {
                          isCheckedEmail = value ?? false;
                        });
                      },
                    ),
                    const Text(
                      'Notificar por email',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: observationsController,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: 'Observações',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    _cancelTask(_Lista_Tarefas); // Pass the task data as an argument
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    minimumSize: const Size(140, 45),
                  ),
                  child: const Text(
                    'CANCELAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(width: 15),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context); // Navigate back to the previous route (main page)
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    minimumSize: const Size(140, 45),
                  ),
                  child: const Text(
                    'VOLTAR',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}