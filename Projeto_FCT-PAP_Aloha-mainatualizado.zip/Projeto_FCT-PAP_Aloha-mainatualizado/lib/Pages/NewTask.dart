
// ignore_for_file: depend_on_referenced_packages

import 'dart:async';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';




class NewTaskPage extends StatefulWidget {
  @override
  _NewTaskPageState createState() => _NewTaskPageState();
}

class _NewTaskPageState extends State<NewTaskPage> {
  String selectedOption = 'Reunião';
  String selectedUser = 'Manager';
  String selectedStatus = 'Sem Status';
  String selectedEntity = 'Aloha,lda';
  String selectedContact = 'ALOHA,lda';
  TextEditingController _assuntoTarefaController = TextEditingController();
  TextEditingController _descricaoTarefaController = TextEditingController();
  TextEditingController _inicioTarefaController = TextEditingController();
  TextEditingController _fimTarefaController = TextEditingController();

  String? _token;

  @override
  void initState() {
    super.initState();

    // Access the token from SharedPreferences
    SharedPreferences.getInstance().then((sharedPreferences) {
      setState(() {
        _token = sharedPreferences.getString('login_token');
      });

      // Fetch and print the data from the URLs
      fetchSubcontacts(824);
      fetchSubcontactProcess(13);
    });
  }

  Future<void> _selectDate(BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2025),
    );

    if (picked != null && picked != DateTime.now()) {
      setState(() {
        controller.text = DateFormat('yyyy-MM-dd').format(picked); // Format the date
      });
    }
  }

  Future<void> fetchSubcontacts(int id) async {
    if (_token != null) {
      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      };

      final response = await http.get(
        Uri.parse('https://demo.spot4all.com/sub-contacts/$id'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        // print('Fetched subcontacts data: $data');
      } else {
        print('Failed to fetch subcontacts. Response status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        throw Exception('Failed to fetch subcontacts');
      }
    } else {
      print('No valid token available');
    }
  }

  Future<List<dynamic>> fetchSubcontactProcess(int id) async {
    if (_token != null) {
      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      };

      final response = await http.get(
        Uri.parse('https://demo.spot4all.com/get_subcontact_process/$id'),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        // print('Fetched data: $data');
        return data;
      } else {
        print('Failed to fetch subcontact process. Response status code: ${response.statusCode}');
        print('Response body: ${response.body}');
        throw Exception('Failed to fetch subcontact process');
      }
    } else {
      print('No valid token available');
      throw Exception('No valid token available');
    }
  }

  Future<void> createTask() async {
    final SharedPreferences _sharedPreferences = await SharedPreferences.getInstance();
    final String? _token = _sharedPreferences.getString('login_token');
    final int? _id = _sharedPreferences.getInt('id_user');

    if (_token != null && _id != null) {
      final Map<String, dynamic> taskData = {
        'id_contacto': 824,
        'sub_contact_id': 13,
        'tipo_contacto': selectedOption,
        'title': _assuntoTarefaController.text,
        'description': _descricaoTarefaController.text,
        'init_date': _inicioTarefaController.text,
        'end_date': _fimTarefaController.text,
        'utilizador_id': _id, // Use the retrieved user ID
        'process_id': 217,
        'status_id': 3,
        'notify_utilizador': 0,
        'notify_subcontacto': 0,
      };

      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_token',
      };

      try {
        final subContactsResponse = await http.get(
          Uri.parse('https://demo.spot4all.com/sub-contacts/824'),
          headers: headers,
        );

        if (subContactsResponse.statusCode == 200) {
          // print('Fetched subcontacts data: $subContactsData');
          // Use the subContactsData as required in your task creation logic
        } else {
          print('Failed to fetch subcontacts. Response status code: ${subContactsResponse.statusCode}');
          print('Response body: ${subContactsResponse.body}');
          throw Exception('Failed to fetch subcontacts');
        }

        final subcontactProcessResponse = await http.get(
          Uri.parse('https://demo.spot4all.com/get_subcontact_process/13'),
          headers: headers,
        );

        if (subcontactProcessResponse.statusCode == 200) {

          // print('Fetched subcontact process data: $subcontactProcessData');
          // Use the subcontactProcessData as required in your task creation logic
        } else {
          print('Failed to fetch subcontact process. Response status code: ${subcontactProcessResponse.statusCode}');
          print('Response body: ${subcontactProcessResponse.body}');
          throw Exception('Failed to fetch subcontact process');
        }

        final response = await http.post(
          Uri.parse('https://demo.spot4all.com/nova-tarefa'),
          headers: headers,
          body: json.encode(taskData),
        );

        if (response.statusCode == 200) {
          // Task created successfully
          // Handle the response or perform any required actions
          print('Task created successfully');
          // or display a toast message

        } else {
          // Task creation failed
          // Handle the error or display an error message
          print('Error creating task: ${response.statusCode}');
        }
      } catch (e) {
        // Error occurred during the request
        // Handle the error or display an error message
        print('Error creating task: $e');
      }
    } else {
      // No valid token or user ID available
      // Handle the case where the token or user ID is missing or invalid
      print('No valid token or user ID available');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Nova Tarefa',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF2c55ca),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Tipo de Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedOption,
            onChanged: (value) {
              setState(() {
                selectedOption = value ?? selectedOption;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Reunião',
                child: Text('Reunião'),
              ),
              DropdownMenuItem<String>(
                value: 'Tarefa',
                child: Text('Tarefa'),
              ),
              DropdownMenuItem<String>(
                value: 'Telefonema',
                child: Text('Telefonema'),
              ),
              DropdownMenuItem<String>(
                value: 'Visita ao cliente',
                child: Text('Visita ao cliente'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Atribuir Utilizador',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedUser,
            onChanged: (value) {
              setState(() {
                selectedUser = value ?? selectedUser;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Manager',
                child: Text('Manager'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Assunto da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _assuntoTarefaController,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Descrição da Tarefa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _descricaoTarefaController,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
          ),
          const Text(
            'Selecionar entidade',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedEntity,
            onChanged: (value) {
              setState(() {
                selectedEntity = value ?? selectedEntity;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Aloha,lda',
                child: Text('Aloha,lda'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Seleccione o subccontacto',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(
                Icons.star,
                color: Colors.orange,
              ),
            ),
            value: selectedContact,
            onChanged: (value) {
              setState(() {
                selectedContact = value ?? selectedContact;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'ALOHA,lda',
                child: Text('ALOHA,lda'),
              ),

            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Status',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            ),
            value: selectedStatus,
            onChanged: (value) {
              setState(() {
                selectedStatus = value ?? selectedStatus;
              });
            },
            items: const [
              DropdownMenuItem<String>(
                value: 'Sem Status',
                child: Text('Sem Status'),
              ),
              DropdownMenuItem<String>(
                value: 'Em Andamento',
                child: Text('Em Andamento'),
              ),
              DropdownMenuItem<String>(
                value: 'Concluído',
                child: Text('Concluído'),
              ),
              DropdownMenuItem<String>(
                value: 'Cancelado',
                child: Text('Cancelado'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'Data de Início',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _inicioTarefaController,
            onTap: () {
              _selectDate(context, _inicioTarefaController);
            },
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(Icons.calendar_today),
            ),
            readOnly: true,
          ),
          const SizedBox(height: 16),
          const Text(
            'Data de Fim',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _fimTarefaController,
            onTap: () {
              _selectDate(context, _fimTarefaController);
            },
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Colors.grey[400]!),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              suffixIcon: const Icon(Icons.calendar_today),
            ),
            readOnly: true,
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              createTask();
            },
            child: const Text('Criar Tarefa'),
          ),
        ],
      ),
    );
  }
}
